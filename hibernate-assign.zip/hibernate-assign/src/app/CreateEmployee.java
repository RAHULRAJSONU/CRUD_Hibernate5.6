package app;

import org.hibernate.Session;

import dto.EmployeeDTO;
import utility.Connection;

public class CreateEmployee {

	public static void main(String[] args) {
		EmployeeDTO emp=new EmployeeDTO();
		emp.setName("Rahul Raj");
		emp.setAge(23);
		emp.setLocation("Bangalore");
		emp.setSalary(2000);
		
		Session session = Connection.getSession().openSession();
		try {			
			session.beginTransaction();
			session.save(emp);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
			Connection.getSession().close();
		}
	}

}
