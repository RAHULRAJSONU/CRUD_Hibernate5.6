package app;

import java.util.List;

import org.hibernate.Session;

import dto.EmployeeDTO;
import utility.Connection;


public class GetAllEmployee 
{
    @SuppressWarnings("unchecked")
	public static void main( String[] args )
    {
    	Session session=Connection.getSession().openSession();
    	try {
			session.beginTransaction();
			List<EmployeeDTO> list = session.createQuery("from EmployeeDTO").list();
			for (EmployeeDTO employeeDTO : list) {
				System.out.println(employeeDTO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
			Connection.getSession().close();
		}
    }
}
