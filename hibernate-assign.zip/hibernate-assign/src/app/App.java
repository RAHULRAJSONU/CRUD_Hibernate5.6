package app;

import java.util.List;

import org.hibernate.Session;

import dto.EmployeeDTO;
import utility.Connection;

public class App 
{
    @SuppressWarnings("unchecked")
	public static void main( String[] args )
    {
        Session session=Connection.getSession().openSession();
        try {
			//employee with salary>20000;
			System.out.println("-------employee with salary>20000------");
			List<EmployeeDTO> list = session.createQuery("from EmployeeDTO where salary>20000").list();
			for (EmployeeDTO employeeDTO : list) {
				System.out.println(employeeDTO);
			}
			//employee with bangalore location;
			System.out.println("");
			System.out.println("-----employee with bangalore location------");
			System.out.println("");
			List<EmployeeDTO> list1 = session.createQuery("from EmployeeDTO where location='Bangalore'").list();
			for (EmployeeDTO employeeDTO : list1) {
				System.out.println(employeeDTO);
			}
			//employee with Chennai location
			System.out.println("");
			System.out.println("-----employee with Chennai location------");
			System.out.println("");
			List<EmployeeDTO> list2 = session.createQuery("from EmployeeDTO where location='Chennai'").list();
			for (EmployeeDTO employeeDTO : list2) {
				System.out.println(employeeDTO);
			}
			//employee Max Salary
			System.out.println("");
			System.out.println("-----employee Max Salary------");
			System.out.println("");
			Double l = (Double) session.createQuery("select max(salary) from EmployeeDTO").uniqueResult();
			System.out.println("Maximum Salary : " + l);
			//employee Min Salary
			System.out.println("");
			System.out.println("-----employee Max Salary------");
			System.out.println("");
			Double l1 = (Double) session.createQuery("select min(salary) from EmployeeDTO").uniqueResult();
			System.out.println("Minimum Salary : " + l1);
			//avg salary
			System.out.println("");
			System.out.println("-----employee Avg Salary------");
			System.out.println("");
			Double l2 = (Double) session.createQuery("select avg(salary) from EmployeeDTO").uniqueResult();
			System.out.println("Average Salary : " + l2);
			//total employee
			System.out.println("");
			System.out.println("-----Total employee------");
			System.out.println("");
			Long l3 = (Long) session.createQuery("select count(*) from EmployeeDTO").uniqueResult();
			System.out.println("Total Employee : " + l3);
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
		session.close();
		Connection.getSession().close();
		}
    }
}
