package utility;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class Connection {
	
	private static SessionFactory s;
	
	public static SessionFactory getSession(){
		if (s==null){
		Configuration config=new Configuration();
					  config.configure();
		SessionFactory factory = config.buildSessionFactory();
		s=factory;
		}
		return s;
	}
	
}
